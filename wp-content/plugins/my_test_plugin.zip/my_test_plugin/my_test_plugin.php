<?php

/**
 * Plugin Name: My Test Plugin
 * Plugin URI: https://wordpress.org/
 * Description: This is a Test Plugin
 * Version: 1.0.0
 * Author: Sumanta Halder
 * Author Uri: https://techsumanta.com/
 */

if(!defined('ABSPATH')) {
    header('location: /my-plugin-test/wp-admin');
    die();
}

register_activation_hook(__FILE__, 'my_plugin_activation');

function my_plugin_activation() {
    global $wpdb, $table_prefix;

    $wp_emp = $table_prefix."emp";
    
    $create_table_sql = "CREATE TABLE IF NOT EXISTS `$wp_emp` 
                        (`id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(100) NOT NULL ,
                         `email` VARCHAR(255) NOT NULL , `status` SMALLINT(2) NOT NULL ,
                          PRIMARY KEY (`id`)) ENGINE = InnoDB";
    
    $wpdb->query($create_table_sql);

    $insert_data = array(
        'name' => 'Sumanta',
        'email' => 'abc@gmail.com',
        'status' => 1
    );

    $wpdb->insert($wp_emp, $insert_data);
}

register_deactivation_hook(__FILE__, 'my_plugin_deactivation');

function my_plugin_deactivation() {
    global $wpdb, $table_prefix;
    
    $wp_emp = $table_prefix."emp";

    $truncate_table_sql = "TRUNCATE TABLE `$wp_emp`";
    $wpdb->query($truncate_table_sql);
}
?>